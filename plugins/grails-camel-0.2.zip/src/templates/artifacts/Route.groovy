@artifact.package@
class @artifact.name@ {
    def configure = {

	}
}
